//
//  APISession.swift
//  DemoCheckList
//
//  Created by i-Phone14 on 07/10/16.
//  Copyright © 2016 Trainee2. All rights reserved.
//

import UIKit

class APISession: NSObject
{
    
    class func getDataWithRequestWithToken(withAPIName strAPIName: (String), completionHandler:@escaping (_ response:NSArray?,_ status:Bool)->Void)
    {
        let URL=Foundation.URL(string:"http://192.168.1.129:8380/discus-cloud-web/rs/"+strAPIName)
        
        let request=NSMutableURLRequest(url: URL!)
        request.httpMethod="GET"
                request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("ZTRY62UQ55Y5Q31NTYVXW3YZ30P102OR", forHTTPHeaderField: "token")
        
        let session = URLSession.shared.dataTask(with: request as URLRequest,completionHandler: { (data, response, error) in
            if error==nil
            {
                DispatchQueue.main.async(execute: {
                    let dicResponse = try? JSONSerialization .jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments) as! NSArray
                    completionHandler(dicResponse, error==nil)
                })
            }
            else
            {
                completionHandler(nil, error==nil)
            }
        })
        session.resume()
    }
}



