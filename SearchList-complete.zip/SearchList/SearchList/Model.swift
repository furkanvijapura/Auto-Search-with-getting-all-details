//
//  Model.swift
//  SearchBar
//
//  Created by Shinkangsan on 12/20/16.
//  Copyright © 2016 Sheldon. All rights reserved.
//

import UIKit
var DicData:NSArray = NSArray()
class Model: NSObject {
    var OrganizationName: String = ""
    var OrganizationType: String = ""
    var isUser: String = ""
    var ID: String = ""
    var ProLogo : String = ""
    
    init(OrgName:String,OrgType:String,User:String,IDN:String,ProfileLogo:String) {
        self.OrganizationName = OrgName
        self.OrganizationType = OrgType
        self.isUser = User
        self.ID = IDN
        self.ProLogo = ProfileLogo
        
    }
    
    class func generateModelArray() -> [Model]{
        var modelAry = [Model]()
        
        for i in 0..<DicData.count
        {
            var id = (DicData.object(at: i) as! NSDictionary).value(forKey: "id") as! Int
            
            var OrganizatioName =  (DicData.object(at: i) as! NSDictionary).value(forKey: "organizationName") as! String
            var type = (DicData.object(at: i) as! NSDictionary).value(forKey: "type") as! String
            var imgPro = (DicData.object(at: i) as! NSDictionary).value(forKey: "logoName") as! String
            var isUser = (DicData.object(at: i) as! NSDictionary).value(forKey: "isUser") as! Int
            
            if id == NL0
            {
                id = 0
            }
            if OrganizatioName == ""
            {
                OrganizatioName = "NA"
            }
            if type == ""
            {
                type = "NA"
            }
            if imgPro == ""
            {
                imgPro = "NA"
            }
            if isUser == 0
            {
                isUser = 0
            }
            else if isUser == 1
            {
                isUser = 1
            }
            else
            {
                isUser = 3
            }
            print("ID :: ",id,"name :: ",OrganizatioName,"type ::",type,"imgPro ::",imgPro,"isUser :: ",isUser)
            modelAry.append(Model(OrgName: OrganizatioName, OrgType: type, User: String(isUser), IDN: String(id), ProfileLogo: imgPro))
        }

        return modelAry
    }
}
