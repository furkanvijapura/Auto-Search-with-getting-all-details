//
//  CompanyListCell.swift
//  Odin_App_Project_Swift
//
//  Created by Sunil Yadav on 17/11/17.
//  Copyright © 2017 discussolutions. All rights reserved.
//

import UIKit

class CompanyListCell: UITableViewCell {

    @IBOutlet weak var imgUser: UIImageView!
    @IBOutlet weak var lblCompanyType: UILabel!
    @IBOutlet weak var btnProfilePic: UIButton!
    @IBOutlet weak var lblCompanyName: UILabel!
    override func awakeFromNib()
    {
        super.awakeFromNib()
        btnProfilePic.layer.cornerRadius=22.5
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setDefaultImage1(name: String)
    {
        self.btnProfilePic.setTitle(String(name[name.startIndex]), for: .normal)
        self.btnProfilePic.backgroundColor = pickColor(alphabet: name[name.startIndex])
        self.btnProfilePic.isEnabled = true
    }
    
    func setDefaultImage2(name: String,name1: String)
    {
        self.btnProfilePic.setTitle(String(name[name.startIndex]) + String(name1[name1.startIndex]), for: .normal)
        self.btnProfilePic.backgroundColor = pickColor(alphabet: name[name.startIndex])
        self.btnProfilePic.isEnabled = true
    }
    
    func pickColor(alphabet: Character) -> UIColor
    {
        let myColor: UIColor = .random
        let alphabetColors = myColor
        let str = String(alphabet).unicodeScalars
        let unicode = Int(str[str.startIndex].value)
        return alphabetColors
    }

}
extension UIColor
{
    static var random: UIColor
    {
        return UIColor(red: .random, green: .random, blue: .random, alpha: 1.0)
    }
}
extension CGFloat
{
    static var random: CGFloat
    {
        return CGFloat(arc4random()) / CGFloat(UInt32.max)
    }
}

