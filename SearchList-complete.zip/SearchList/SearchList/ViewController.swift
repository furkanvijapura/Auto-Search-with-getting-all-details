//
//  ViewController.swift
//  SearchList
//
//  Created by Sunil Yadav on 11/12/17.
//  Copyright © 2017 Discus IT. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        APISession.getDataWithRequestWithToken( withAPIName:"common/contacts" )
        {
            (response, permissions) in
            if response != nil
            {
                DicData = (response)!
                print("DicData ::",DicData)
                let sto = self.storyboard?.instantiateViewController(withIdentifier: "CompanyListScreen") as! CompanyListScreen
                self.navigationController?.pushViewController(sto, animated: true)
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }


}

