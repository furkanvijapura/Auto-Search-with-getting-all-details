//
//  CompanyListScreen.swift
//  Odin_App_Project_Swift
//
//  Created by Sunil Yadav on 17/11/17.
//  Copyright © 2017 discussolutions. All rights reserved.
//

import UIKit

class CompanyListScreen: UIViewController,UITableViewDelegate,UITableViewDataSource, UISearchBarDelegate {
    let initialDataAry:[Model] = Model.generateModelArray()
    var dataAry:[Model] = Model.generateModelArray()
    
    @IBOutlet weak var btnFilter: UIButton!
    @IBOutlet weak var txtEnable: UITextField!
    @IBOutlet weak var tblCompanyList: UITableView!
    @IBOutlet weak var searchBarCompany: UISearchBar!
    var  arrCompanydata = NSArray()
    var  arrSelectData = NSMutableArray()
    var arrAutosearchProduct = NSArray()
    var searchActive : Bool = false
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.title = "Company"
        self.navigationItem.hidesBackButton = true
        searchBarCompany.delegate = self
        
    }
    func filterTableView(text:String) {
       
            dataAry = initialDataAry.filter({ (mod) -> Bool in
                return mod.OrganizationName.lowercased().contains(text.lowercased())
            })
            self.tblCompanyList.reloadData()
      
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    @IBAction func btnFilterTapped(_ sender: Any)
    {
//        let objReg=self.storyboard?.instantiateViewController(withIdentifier: "CompanyPeopleFilterScreen") as! CompanyPeopleFilterScreen
//        self.navigationController?.pushViewController(objReg, animated: true)
    }
    
    func tableView(_ tableView:  UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
       return dataAry.count
    }
   

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! CompanyListCell
         let model = dataAry[indexPath.row]
        cell.lblCompanyName.text = model.OrganizationName
        cell.lblCompanyType.text = model.OrganizationType
        if model.isUser == "0"
        {
            cell.imgUser.image = UIImage(named: "1")
        }
        if model.isUser == "1"
        {
            cell.imgUser.image = UIImage(named: "2")
        }
        return cell
    }
   
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchActive = true;
    }
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchActive = false;
    }
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchActive = false;
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchActive = false;
        searchBar.resignFirstResponder()
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String)
    {
        if searchText.isEmpty {
            dataAry = initialDataAry
            tblCompanyList.reloadData()
        }else {
            filterTableView(text: searchText)
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let model = dataAry[indexPath.row]
        let alert = UIAlertController(title: "Your Selected ID", message: model.ID, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}

//func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
//    {
////        let selectedCell:CompanyListCell = tableView.cellForRow(at: indexPath as IndexPath)! as! CompanyListCell
////        selectedCell.contentView.backgroundColor = UIColor(red: 0/255, green: 134/255, blue: 186/255, alpha: 1.0)
//        //CompanyProfileScreen
////         PeopleProfileScreen
//
//        if (!searchActive)
//        {
//            let objData : NSDictionary = self.arrCompanydata[indexPath.row] as! NSDictionary
//            if let isUserType:Bool = objData.value(forKey: "isUser") as? Bool
//            {
//                if isUserType==true
//                {
//                    let objReg=self.storyboard?.instantiateViewController(withIdentifier: "PeopleProfileScreen") as!PeopleProfileScreen
//                    let orgId:NSArray=(self.arrCompanydata as AnyObject).value(forKey: "id") as! NSArray
//                    let id: NSNumber = (orgId.object(at: indexPath.row) as! NSNumber)
//                    objReg.companyId = id.stringValue as NSString
//                    self.navigationController?.pushViewController(objReg, animated: true)
//                }
//                else{
//                    let objReg=self.storyboard?.instantiateViewController(withIdentifier: "CompanyProfileScreen") as!CompanyProfileScreen
//                    let orgId:NSArray=(self.arrCompanydata as AnyObject).value(forKey: "id") as! NSArray
//                    let id: NSNumber = (orgId.object(at: indexPath.row) as! NSNumber)
//                    objReg.companyId = id.stringValue as NSString
//                    self.navigationController?.pushViewController(objReg, animated: true)
//                }
//        }
//        }
//        else
//        {
////        let objData : String = self.arrAutosearchProduct[indexPath.row] as! String
////         print("id===",objData)
//        }
//    }
